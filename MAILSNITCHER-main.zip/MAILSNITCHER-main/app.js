function google(){
    window.open("https://www.google.com/")
}

function microsoft(){
    window.open("https://www.microsoft.com/en-in")
}

function yahoo(){
    window.open("https://in.yahoo.com/")
}